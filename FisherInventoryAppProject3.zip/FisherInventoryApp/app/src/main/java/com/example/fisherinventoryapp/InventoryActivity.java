package com.example.fisherinventoryapp;

import android.database.Cursor;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.core.content.ContextCompat;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private GridLayout inventoryGrid;
    private EditText itemNameInput;
    private EditText itemQuantityInput;
    private Button addItemButton;

    private DatabaseHelper databaseHelper;

    private static final String PREFS_NAME = "notification_preferences";
    private static final String SMS_ENABLED = "sms_alerts_enabled";
    private static final String PHONE_NUMBER = "phone_number";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryGrid = findViewById(R.id.inventoryGrid);
        itemNameInput = findViewById(R.id.itemNameInput);
        itemQuantityInput = findViewById(R.id.itemQuantityInput);
        addItemButton = findViewById(R.id.addItemButton);

        Button notificationSettingsButton =
                findViewById(R.id.notificationSettingsButton);

        databaseHelper = new DatabaseHelper(this);

        addItemButton.setOnClickListener(v -> addItem());

        notificationSettingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    InventoryActivity.this,
                    NotificationActivity.class
            );

            startActivity(intent);
        });

        loadInventory();
    }

    private void addItem() {
        String name = itemNameInput.getText().toString().trim();
        String quantityText = itemQuantityInput.getText().toString().trim();

        if (name.isEmpty() || quantityText.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter an item name and quantity.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        int quantity;

        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            Toast.makeText(
                    this,
                    "Please enter a valid quantity.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (quantity < 0) {
            Toast.makeText(
                    this,
                    "Quantity cannot be negative.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (databaseHelper.addInventoryItem(name, quantity)) {
            Toast.makeText(
                    this,
                    "Item added.",
                    Toast.LENGTH_SHORT
            ).show();

            itemNameInput.setText("");
            itemQuantityInput.setText("");

            loadInventory();
        } else {
            Toast.makeText(
                    this,
                    "Item could not be added.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void loadInventory() {

        // Keep the three header views and remove old inventory rows
        if (inventoryGrid.getChildCount() > 3) {
            inventoryGrid.removeViews(
                    3,
                    inventoryGrid.getChildCount() - 3
            );
        }

        Cursor cursor = databaseHelper.getAllInventoryItems();

        while (cursor.moveToNext()) {

            int itemId = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id")
            );

            String itemName = cursor.getString(
                    cursor.getColumnIndexOrThrow("item_name")
            );

            int quantity = cursor.getInt(
                    cursor.getColumnIndexOrThrow("quantity")
            );

            addInventoryRow(itemId, itemName, quantity);
        }

        cursor.close();
    }

    private void addInventoryRow(int itemId, String itemName, int quantity) {

        // Item name
        TextView nameText = new TextView(this);
        nameText.setText(itemName);
        nameText.setGravity(Gravity.CENTER_VERTICAL);

        GridLayout.LayoutParams nameParams =
                new GridLayout.LayoutParams();

        nameParams.width = dpToPx(120);
        nameParams.height = dpToPx(56);

        nameText.setLayoutParams(nameParams);
        inventoryGrid.addView(nameText);

        // Quantity
        TextView quantityText = new TextView(this);
        quantityText.setText(String.valueOf(quantity));
        quantityText.setGravity(Gravity.CENTER);

        GridLayout.LayoutParams quantityParams =
                new GridLayout.LayoutParams();

        quantityParams.width = dpToPx(50);
        quantityParams.height = dpToPx(56);

        quantityText.setLayoutParams(quantityParams);
        inventoryGrid.addView(quantityText);

        // Actions
        LinearLayout actionsLayout = new LinearLayout(this);
        actionsLayout.setOrientation(LinearLayout.HORIZONTAL);
        actionsLayout.setGravity(Gravity.CENTER);

        GridLayout.LayoutParams actionsParams =
                new GridLayout.LayoutParams();

        actionsParams.width = dpToPx(190);
        actionsParams.height = dpToPx(56);

        actionsLayout.setLayoutParams(actionsParams);

        // Minus button
        Button minusButton = new Button(this);
        minusButton.setText("-");
        minusButton.setTextSize(18);

        LinearLayout.LayoutParams smallButtonParams =
                new LinearLayout.LayoutParams(
                        dpToPx(48),
                        dpToPx(48)
                );

        minusButton.setLayoutParams(smallButtonParams);

        minusButton.setOnClickListener(v -> {

            int newQuantity = Math.max(0, quantity - 1);

            boolean updated =
                    databaseHelper.updateInventoryQuantity(
                            itemId,
                            newQuantity
                    );

            // Send an alert only when the item changes from 1 to 0
            if (updated && quantity == 1 && newQuantity == 0) {
                sendLowInventorySms(itemName);
            }

            loadInventory();
        });

        // Plus button
        Button plusButton = new Button(this);
        plusButton.setText("+");
        plusButton.setTextSize(18);

        LinearLayout.LayoutParams plusParams =
                new LinearLayout.LayoutParams(
                        dpToPx(48),
                        dpToPx(48)
                );

        plusButton.setLayoutParams(plusParams);

        plusButton.setOnClickListener(v -> {

            databaseHelper.updateInventoryQuantity(
                    itemId,
                    quantity + 1
            );

            loadInventory();
        });

        // Delete button
        Button deleteButton = new Button(this);
        deleteButton.setText("Delete");
        deleteButton.setTextSize(12);

        LinearLayout.LayoutParams deleteParams =
                new LinearLayout.LayoutParams(
                        dpToPx(90),
                        dpToPx(48)
                );

        deleteButton.setLayoutParams(deleteParams);

        deleteButton.setOnClickListener(v -> {

            databaseHelper.deleteInventoryItem(itemId);

            Toast.makeText(
                    this,
                    "Item deleted.",
                    Toast.LENGTH_SHORT
            ).show();

            loadInventory();
        });

        actionsLayout.addView(minusButton);
        actionsLayout.addView(plusButton);
        actionsLayout.addView(deleteButton);

        inventoryGrid.addView(actionsLayout);
    }

    private void sendLowInventorySms(String itemName) {

        SharedPreferences preferences =
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        boolean smsEnabled =
                preferences.getBoolean(
                        SMS_ENABLED,
                        false
                );

        String phoneNumber =
                preferences.getString(
                        PHONE_NUMBER,
                        ""
                );

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        // If the user turned alerts off or denied permission,
        // inventory still works normally.
        if (!smsEnabled || !permissionGranted) {
            return;
        }

        if (phoneNumber == null || phoneNumber.trim().isEmpty()) {

            Toast.makeText(
                    this,
                    "No phone number is saved.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        String message =
                "Inventory Alert: " +
                        itemName +
                        " has reached zero stock.";

        try {

            SmsManager smsManager =
                    getSystemService(SmsManager.class);

            if (smsManager != null) {

                smsManager.sendTextMessage(
                        phoneNumber,
                        null,
                        message,
                        null,
                        null
                );

                Toast.makeText(
                        this,
                        "SMS alert triggered.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "SMS is not available on this device.",
                        Toast.LENGTH_SHORT
                ).show();
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "SMS alert could not be sent.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private int dpToPx(int dp) {
        float density = getResources()
                .getDisplayMetrics()
                .density;

        return Math.round(dp * density);
    }
}