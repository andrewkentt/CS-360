package com.example.fisherinventoryapp;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity {

    private TextView notificationStatusText;

    private SharedPreferences preferences;

    private ActivityResultLauncher<String> smsPermissionLauncher;

    private static final String PREFS_NAME = "notification_preferences";
    private static final String SMS_ENABLED = "sms_alerts_enabled";

    private static final String PHONE_NUMBER = "phone_number";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        notificationStatusText =
                findViewById(R.id.notificationStatusText);

        Button allowNotificationsButton =
                findViewById(R.id.allowNotificationsButton);

        Button declineNotificationsButton =
                findViewById(R.id.declineNotificationsButton);

        EditText phoneNumberInput =
                findViewById(R.id.phoneNumberInput);

        Button savePhoneNumberButton =
                findViewById(R.id.savePhoneNumberButton);

        preferences =
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        String savedPhoneNumber =
                preferences.getString(PHONE_NUMBER, "");

        phoneNumberInput.setText(savedPhoneNumber);

        smsPermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.RequestPermission(),
                        isGranted -> {

                            if (isGranted) {

                                preferences.edit()
                                        .putBoolean(SMS_ENABLED, true)
                                        .apply();

                                notificationStatusText.setText(
                                        R.string.sms_enabled
                                );

                            } else {

                                preferences.edit()
                                        .putBoolean(SMS_ENABLED, false)
                                        .apply();

                                notificationStatusText.setText(
                                        R.string.sms_denied
                                );
                            }
                        }
                );

        allowNotificationsButton.setOnClickListener(v ->
                requestSmsPermission()
        );

        declineNotificationsButton.setOnClickListener(v -> {

            preferences.edit()
                    .putBoolean(SMS_ENABLED, false)
                    .apply();

            notificationStatusText.setText(
                    R.string.sms_disabled
            );
        });

        savePhoneNumberButton.setOnClickListener(v -> {

            String phoneNumber =
                    phoneNumberInput.getText()
                            .toString()
                            .trim();

            if (phoneNumber.isEmpty()) {

                Toast.makeText(
                        this,
                        R.string.enter_phone_number,
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            preferences.edit()
                    .putString(PHONE_NUMBER, phoneNumber)
                    .apply();

            Toast.makeText(
                    this,
                    R.string.phone_number_saved,
                    Toast.LENGTH_SHORT
            ).show();
        });

        updateStatus();
    }

    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED) {

            preferences.edit()
                    .putBoolean(SMS_ENABLED, true)
                    .apply();

            notificationStatusText.setText(
                    R.string.sms_enabled
            );

        } else {

            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    private void updateStatus() {

        boolean alertsEnabled =
                preferences.getBoolean(
                        SMS_ENABLED,
                        false
                );

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (alertsEnabled && permissionGranted) {

            notificationStatusText.setText(
                    R.string.sms_enabled
            );

        } else {

            notificationStatusText.setText(
                    R.string.permission_not_selected
            );
        }
    }
}