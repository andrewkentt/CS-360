package com.example.fisherinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private Button createAccountButton;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect the Java code to the login screen
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Open the app database
        databaseHelper = new DatabaseHelper(this);

        loginButton.setOnClickListener(v -> loginUser());

        createAccountButton.setOnClickListener(v -> createAccount());
    }

    private void loginUser() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        // Make sure both fields have been entered
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Check the username and password against the database
        if (databaseHelper.checkUser(username, password)) {
            Toast.makeText(
                    this,
                    "Login successful.",
                    Toast.LENGTH_SHORT
            ).show();

            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            startActivity(intent);

        } else {
            Toast.makeText(
                    this,
                    "Incorrect username or password.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    private void createAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString();

        // Make sure both fields have been entered
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please enter a username and password.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Do not allow duplicate usernames
        if (databaseHelper.userExists(username)) {
            Toast.makeText(
                    this,
                    "That username already exists.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        // Save the new account to the database
        if (databaseHelper.addUser(username, password)) {
            Toast.makeText(
                    this,
                    "Account created. You can now log in.",
                    Toast.LENGTH_SHORT
            ).show();

            passwordInput.setText("");

        } else {
            Toast.makeText(
                    this,
                    "Account could not be created.",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}